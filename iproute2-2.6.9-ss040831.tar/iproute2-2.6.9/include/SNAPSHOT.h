static char SNAPSHOT[] = "040831";
